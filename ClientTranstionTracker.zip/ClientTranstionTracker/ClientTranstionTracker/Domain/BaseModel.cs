﻿namespace ClientTranstionTracker.Domain
{
    public class BaseModel
    {
    }
}
