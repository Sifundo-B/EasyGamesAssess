﻿namespace ClientTranstionTracker.Domain
{
    public class Client : BaseModel
    {
        public int ClientID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public decimal ClientBalance { get; set; }
    }
}
