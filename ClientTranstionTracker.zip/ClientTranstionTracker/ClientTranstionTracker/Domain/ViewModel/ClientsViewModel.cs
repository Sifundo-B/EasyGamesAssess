﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace ClientTranstionTracker.Domain.ViewModel
{
    public class ClientsViewModel
    {
        public IEnumerable<SelectListItem> Clients { get; set; } 
    }
}
