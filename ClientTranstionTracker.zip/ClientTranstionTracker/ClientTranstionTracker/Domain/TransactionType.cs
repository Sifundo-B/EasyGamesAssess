﻿namespace ClientTranstionTracker.Domain
{
    public class TransactionType : BaseModel
    {
        public int TransactionTypeID { get; set; }
        public string TransactionTypeName { get; set; }
    }
}
