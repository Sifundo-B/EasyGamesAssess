﻿using ClientTranstionTracker.Domain;
using ClientTranstionTracker.Domain.ViewModel;
using ClientTranstionTracker.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ClientTranstionTracker.Controllers
{
    public class TransactionTypesController : Controller
    {
        private readonly ITransactionTypeRepository _transactionTypeRepository;
        private readonly IClientRepository _clientRepository;
        private readonly ITransactionRepository _transactionRepository;

        public TransactionTypesController(ITransactionTypeRepository transactionTypeRepository, IClientRepository clientRepository,ITransactionRepository transactionRepository)
        {
            _transactionTypeRepository = transactionTypeRepository;
            _clientRepository = clientRepository;
            _transactionRepository = transactionRepository;
        }
        public async Task<IActionResult> Index() => View("~/Pages/TransactionTypes/Index.cshtml", await _transactionTypeRepository.GetAllAsync());

        public async Task<JsonResult> Create(TransactionType transactionType) => Json(await _transactionTypeRepository.CreateAsync(transactionType));
        [HttpGet]
        public async Task<JsonResult> Edit(int transactionTypeId) => Json(await _transactionTypeRepository.GetByIdAsync(transactionTypeId));
        [HttpPost]
        public async Task<JsonResult> Edit(TransactionType transactionType) => Json(await _transactionTypeRepository.UpdateAsync(transactionType));

        public IActionResult Clients() {
          return  View("~/Pages/TransactionTypes/Clients.cshtml", new ClientsViewModel() { Clients = _clientRepository.getClientsAsSelectListItems().Result });
        }

        public async Task<JsonResult> GetTransactions(int clientId) => Json(await _transactionRepository.GetClientsTranstions(clientId));


    }
}
