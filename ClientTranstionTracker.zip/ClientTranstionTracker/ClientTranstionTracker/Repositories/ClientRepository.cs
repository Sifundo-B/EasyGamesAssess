﻿using ClientTranstionTracker.Domain;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ClientTranstionTracker.Repositories
{
    public class ClientRepository : BaseRepository, IClientRepository
    {
        public ClientRepository(IConfiguration configuration) : base(configuration)
        {
        }
        public async Task<int> CreateAsync(Client entity)
        {
            try
            {
                var sp = "spInsertClient";
                var parameters = new DynamicParameters();
                parameters.Add("Name", entity.Name, DbType.String);
                parameters.Add("Surname", entity.Surname, DbType.String);
                parameters.Add("ClientBalance", entity.ClientBalance, DbType.Decimal);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> DeleteAsync(Client entity)
        {
            try
            {
                var sp = "spDeleteClient";
                var parameters = new DynamicParameters();
                parameters.Add("ClientID", entity.ClientID, DbType.Int32);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<List<Client>> GetAllAsync()
        {
            try
            {
                var sp = "spGetAllClients";
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryAsync<Client>(sp)).AsList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<Client> GetByIdAsync(int id)
        {
            try
            {
                var sp = "spGetClient";
                var parameters = new DynamicParameters();
                parameters.Add("ClientID", id, DbType.Int32);
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryFirstOrDefaultAsync<Client>(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> UpdateAsync(Client entity)
        {
            try
            {
                var sp = "spUpdateClient";
                var parameters = new DynamicParameters();
                parameters.Add("ClientID", entity.ClientID, DbType.Int32);
                parameters.Add("Name", entity.Name, DbType.String);
                parameters.Add("Surname", entity.Surname, DbType.String);
                parameters.Add("ClientBalance", entity.ClientBalance, DbType.Decimal);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
