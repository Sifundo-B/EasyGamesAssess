﻿using ClientTranstionTracker.Domain;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ClientTranstionTracker.Repositories
{
    public class TransactionTypeRepository : BaseRepository, ITransactionTypeRepository
    {
        public TransactionTypeRepository(IConfiguration configuration) : base(configuration)
        {
        }

        public async Task<int> CreateAsync(TransactionType entity)
        {
            try
            {
                var sp = "spInsertTransactionType";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionTypeName", entity.TransactionTypeName, DbType.String);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp,parameters,null,null,CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> DeleteAsync(TransactionType entity)
        {
            try
            {
                var sp = "spDeleteTransactionType";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionTypeId", entity.TransactionTypeID, DbType.Int32);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<List<TransactionType>> GetAllAsync()
        {
            try
            {
                var sp = "spGetAllTransactionTypes";
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryAsync<TransactionType>(sp)).AsList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<TransactionType> GetByIdAsync(int id)
        {
            try
            {
                var sp = "spGetTransactionType";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionTypeId", id, DbType.Int32);
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryFirstOrDefaultAsync<TransactionType>(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }

        }

        public async Task<int> UpdateAsync(TransactionType entity)
        {

            try
            {
                var sp = "spUpdateTransactionType";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionTypeId", entity.TransactionTypeID, DbType.Int32);

                parameters.Add("TransactionTypeName", entity.TransactionTypeName, DbType.String);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters,null,null,CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
