﻿using ClientTranstionTracker.Domain;
namespace ClientTranstionTracker.Repositories
{
    public interface ITransactionTypeRepository : IRepository<TransactionType>
    {
    }
}
