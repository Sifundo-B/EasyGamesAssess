﻿using ClientTranstionTracker.Domain;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClientTranstionTracker.Repositories
{
    public interface IClientRepository : IRepository<Client>
    {

        public async Task<IEnumerable<SelectListItem>> getClientsAsSelectListItems()
        {
            try
            {
                List<Client> list = await GetAllAsync();
                List<SelectListItem> selectListItems = new List<SelectListItem>();
                list.ForEach(client =>
                {
                    selectListItems.Add(new SelectListItem()
                    {
                        Text = client.Name + " " + client.Surname,
                        Value = client.ClientID.ToString()
                    });
                });

                return selectListItems;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

    }
}
