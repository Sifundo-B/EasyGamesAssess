﻿using ClientTranstionTracker.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClientTranstionTracker.Repositories
{
    public interface ITransactionRepository : IRepository<Transaction>
    {

        public async Task<List<Transaction>> GetClientsTranstions(int clientId)
        {
            List<Transaction> list = await GetAllAsync();
            List<Transaction> ListItems = new List<Transaction>();
            list.ForEach(transxn =>
            {
                if (transxn.ClientID == clientId)
                {
                    ListItems.Add(new Transaction()
                    {
                        TransactionID = transxn.TransactionID,
                        TransactionTypeID = transxn.TransactionTypeID,
                        Amount = transxn.Amount,
                        Comment = transxn.Comment,
                        ClientID = transxn.ClientID
                    });
                }
            });

            return ListItems;

        }
    }
}
