﻿using ClientTranstionTracker.Domain;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ClientTranstionTracker.Repositories
{
    public class TransactionRepository : BaseRepository, ITransactionRepository
    {
        public TransactionRepository(IConfiguration configuration) : base(configuration)
        {
        }

        public async Task<int> CreateAsync(Transaction entity)
        {
            try
            {
                var sp = "spInsertTransaction";
                var parameters = new DynamicParameters();
                parameters.Add("ClientID", entity.ClientID, DbType.Int32);
                parameters.Add("TransactionTypeID", entity.TransactionTypeID, DbType.Int32);
                parameters.Add("Comment", entity.Comment, DbType.String);
                parameters.Add("Amount", entity.Amount, DbType.Decimal);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> DeleteAsync(Transaction entity)
        {
            try
            {
                var sp = "spDeleteTransaction";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionID", entity.TransactionID, DbType.Int32);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<List<Transaction>> GetAllAsync()
        {
            try
            {
                var sp = "spGetAllTransactions";
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryAsync<Transaction>(sp)).AsList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<Transaction> GetByIdAsync(int id)
        {
            try
            {
                var sp = "spGetTransaction";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionTyID", id, DbType.Int32);
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryFirstOrDefaultAsync<Transaction>(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> UpdateAsync(Transaction entity)
        {
            try
            {
                var sp = "spUpdateTransaction";
                var parameters = new DynamicParameters();
                parameters.Add("TransactionID", entity.TransactionID, DbType.Int32);
                parameters.Add("ClientID", entity.ClientID, DbType.Int32);
                parameters.Add("TransactionTypeID", entity.TransactionTypeID, DbType.Int32);
                parameters.Add("Comment", entity.Comment, DbType.String);
                parameters.Add("Amount", entity.Amount, DbType.Decimal);
                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(sp, parameters, null, null, CommandType.StoredProcedure));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
